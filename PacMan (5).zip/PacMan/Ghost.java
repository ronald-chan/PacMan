import java.awt.*;
import javax.swing.*;
/**
 * Runs the ghost movement for pacman game. 
 * @author Ronald Chan Rushil Saha
 * @version 5/4/17
 */
public class Ghost
{
    private int locX,locY,lastX,lastY;
    private Color color;
    private boolean vuln;
    private int direction;
    private Square[][]panels;
    private boolean blinking;
    /**
     * Sets the color of Ghost.
     */
    public Ghost(Square[][]pan,int x,int y,Color col)
    {
    	color=col;
        panels=pan;
        locX=x;
        locY=y;
    }
    /**
     * Sets vulnerability to desired value.
     * @param			boolean desired val of vuln
     */
    public void setVuln(boolean vul)
    {
    	vuln=vul;
    }
    /**
     * Returns vulnerability.
     * 
     * @return			boolean vuln
     */
    public boolean getVuln()
    {
    	return vuln;
    }
    /**
     * Allows other classes to access private var
     * locX.
     * 
     * @return          int x location of ghost.
     */
    public int getLocX()
    {
        return locX;
    }

    /**
     * Sets the private var locX.
     * 
     * @param           int desired x loc of ghost
     */
    public void setLocX(int loc)
    {
        locX=loc;
    }

    /**
     * Sets private var direction
     * 
     * @param			int desired value of direction
     */
    public void setDirection(int dir)
    {
    	direction=dir;
    }
    /**
     * Returns the private variable direction.
     * 
     * @return			int direction
     */
    public int getDirection()
    {
    	return direction;
    }
    /**
     * Allows other classes to access private var
     * locY.
     * 
     * @return          int y location of ghost
     */
    public int getLocY()
    {
        return locY;
    }

    /**
     * Sets the private var locY.
     * 
     * @param           int desired y loc of ghost
     */
    public void setLocY(int loc)
    {
        locY=loc;
    }

    /**
     * Generates the step that the ghosts take, and sets the new ghost location.
     * 
     * @param			int x desired destination
     * 					int y desired destination
     */
    public void generateMove(int destX,int destY)
    {
    	//System.out.println(locX+"\t"+locY);
    	boolean []sidesOpen = {leftIsOpen(),downIsOpen(),rightIsOpen(),upIsOpen()};
    	//System.out.println(sidesOpen[0]+"\n"+sidesOpen[1]+"\n"+sidesOpen[2]+"\n"+sidesOpen[3]+"\n");
    	int numOpen=countTrue(sidesOpen);//checks how many sides are open for logic block
    	int oldX=locX;//for setting old location to no ghost
    	int oldY=locY;//same as above
    	if(numOpen==2)
    	{
    		if(sidesOpen[0]&&direction!=0)
    		{
    			locX--;
    			direction=180;
    		}
    		else if(sidesOpen[1]&&direction!=90)
    		{
    			locY++;
    			direction=270;
    		}
    		else if(sidesOpen[2]&&direction!=180)
    		{
    			locX++;
    			direction=0;
    		}
    		else if(sidesOpen[3]&&direction!=270)
    		{
    			locY--;
    			direction=90;
    		}
    	}
    	else if(numOpen==3)
    	{
    		
    		if(Math.abs(destX-locX)<Math.abs(destY-locY))
    		{ 
    			if(destY>locY&&sidesOpen[1]&&direction!=90)
   				{
    				locY++;
   					direction=270;
  				}
    			else if(destY<locY&&sidesOpen[3]&&direction!=270)
    			{
    				locY--;
    				direction=90;
    			}
    			else if(destX>locX&&sidesOpen[2]&&direction!=180)
    			{
    				locX++;
    				direction=0;
    			}    	
    			else if(destX<locX&&sidesOpen[0]&&direction!=0)
    			{
    				locX--;
    				direction=180;
    			}
    			else
    			{
    				if(sidesOpen[3]&&direction!=270)
    				{
    					locY--;
    					direction=90;
    				}
    				else if(sidesOpen[1]&&direction!=90)
    				{
    					locY++;
    					direction=270;
    				}
    				else if(sidesOpen[2]&&direction!=180)
    				{
    					locX++;
    					direction=0;
    				}
    				else if(sidesOpen[0]&&direction!=0)
    				{
    					locX--;
    					direction=180;
    				}
    			}
    		}
    		else
    		{
    			if(destX>locX&&sidesOpen[2]&&direction!=180)
    			{
    				locX++;
    				direction=0;
    			}    	
    			else if(destX<locX&&sidesOpen[0]&&direction!=0)
    			{
    				locX--;
    				direction=180;
    			}
    			else if(destY>locY&&sidesOpen[1]&&direction!=90)
   				{
    				locY++;
   					direction=270;
  				}
    			else if(destY<locY&&sidesOpen[3]&&direction!=270)
    			{
    				locY--;
    				direction=90;
    			}
    			if(oldX==locX&&oldY==locY)
    			{
    				if(sidesOpen[2]&&direction!=180)
    				{
    					locX++;
    					direction=0;
    				}
    				else if(sidesOpen[0]&&direction!=0)
    				{
    					locX--;
    					direction=180;
    				}
    				else if(sidesOpen[3]&&direction!=270)
    				{
    					locY++;
    					direction=90;
    				}
    				else if(sidesOpen[1]&&direction!=90)
    				{
    					locY--;
    					direction=270;
    				}
    			}
    		}
    	}
    	else if (numOpen==4)
    	{
    		if(locY==15&&((locX==7&&locX>=destX)||(locX==22&&locX<=destX)))
    		{
    			if(Math.random()+0.5>1.0||direction!=90)
    			{
    				locY++;
    				direction=270;
    			}
    			else
    			{
    				locY--;
    				direction=90;
    			}
    		}
    		if(locY==oldY)
    		{
    			if((Math.abs(destX-locX)<Math.abs(destY-locY)&&destX-locX!=0)||destY-locY==0)
    			{
    				if(destX>locX&&(locX!=22||locY!=15)&&direction!=180)
    				{
    					locX++;
    					direction=0;
    				}
    				else if((locX!=7||locY!=15)&&direction!=0)
    				{
    					locX--;
    					direction=180;
    				}
    			}
    			if(locX==oldX)
    			{
    				if(destY>locY&&direction!=90)
    				{
    					locY++;
    					direction=270;
    				}
    				else if(direction!=270)
    				{
    					locY--;
    					direction=90;
    				}
    			}
    		}
    	}
    	if(oldX==locX&&oldY==locY)
    	{
    		if(direction==0&&sidesOpen[2])
    			locX++;
    		else if(direction==90&&sidesOpen[3])
    			locY--;
    		else if(direction==180&&sidesOpen[0])
    			locX--;
    		else if(direction==270&&sidesOpen[1])
    			locY++;
    	}
    	panels[lastX][lastY].setLingGhost(false);
    	panels[oldX][oldY].setGhost(false);
    	panels[oldX][oldY].setLingGhost(true);
    	panels[oldX][oldY].repaint();
    	panels[locX][locY].setGhost(true);
    	panels[locX][locY].setGColor(color);
    	panels[locX][locY].setVuln(vuln);
    	panels[locX][locY].setFlashing(blinking);
    	panels[locX][locY].repaint();
    	lastX=oldX;
    	lastY=oldY;
    }
    /**
     * Movement after pac eats power pellet.
     */
    public void generateVuln()
    {
    	 generateMove((int)(30*Math.random()),(int)(33*Math.random()));
    }
    /**
     * Random movement for ghosts.
     */
    public void generateRand()
    {
    	panels[lastX][lastY].setLingGhost(false);
    	panels[locX][locY].setGhost(false);
    	panels[locX][locY].setLingGhost(true);
    	panels[locX][locY].repaint();
    	lastX=locX;
    	lastY=locY;
    	direction=(int)(Math.random()*4)*90;
    	boolean []sidesOpen = {leftIsOpen(),downIsOpen(),rightIsOpen(),upIsOpen()};
    	if(direction==0&&sidesOpen[2])
			locX++;
		else if(direction==90&&sidesOpen[3])
			locY--;
		else if(direction==180&&sidesOpen[0])
			locX--;
		else if(direction==270&&sidesOpen[1])
			locY++;
    	panels[locX][locY].setGhost(true);
    	panels[locX][locY].setGColor(color);
    	panels[locX][locY].setVuln(vuln);
    	panels[locX][locY].setFlashing(blinking);
    	panels[locX][locY].repaint();
    	
    }
    /**
     * Sets the var blinking.
     * @param 			boolean blink desired val of blinking
     */
    public void setBlinking(boolean blink)
    {
    	blinking=blink;
    }
    public void setLastX(int x)
    {
    	lastX=x;
    }
    public void setLastY(int y)
    {
    	lastY=y;
    }
    /**
     * Returns last value of x.
     * @return			int lastX
     */
    public int getLastX()
    {
    	return lastX;
    }
    /**
     * Returns last value of y.
     * @return			int lastY
     */
    public int getLastY()
    {
    	return lastY;
    }
    /**
     * Counts the number "true" in array
     * 
     * @param 			boolean[] arr 
     * @return			int number true in arr
     */
    public int countTrue(boolean[]arr)
    {
    	int count=0;
    	for(int i=0;i<arr.length;i++)
    	{
    		if(arr[i])
    			count++;
    	}
    	return count;
    }
    /**
     * Returns the index of the first true.
     * 
     * @param			boolean[]
     * @return			index of first true, -1 if all false
     */
    public int whichTrue(boolean []arr)
    {
    	for(int i=0;i<arr.length;i++)
    	{
    		if(arr[i])
    		{
    			return i;
    		}
    	}
    	return -1;
    }
    /**
     * Checks if the space above ghost is open.
     * 
     * @return			boolean true if clear, else false. 
     */
    public boolean upIsOpen()
    {
        if(panels[locX][locY-1].getContents().indexOf("wall")==-1)
        {
            return true;
        }
        else
        {
        	return false;
        }
        //return false;
    }
    /**
     * Checks if the space beneath ghost is open.
     * 
     * @return			boolean true if clear, else false. 
     */
    public boolean downIsOpen()
    {
        if(panels[locX][locY+1].getContents().indexOf("wall")==-1)
        {
            return true;
        }
        return false;
    }
    /**
     * Checks if the space to left ghost is open.
     * 
     * @return			boolean true if clear, else false. 
     */
    public boolean leftIsOpen()
    {
        if(panels[locX-1][locY].getContents().indexOf("wall")==-1)
        {
            return true;
        }
        return false;
    }
    /**
     * Checks if the space to right ghost is open.
     * 
     * @return			boolean true if clear, else false. 
     */
    public boolean rightIsOpen()
    {
        if(panels[locX+1][locY].getContents().indexOf("wall")==-1)
        { 
            return true;
        }
        return false;
    }
}
