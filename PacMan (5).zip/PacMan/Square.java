import java.awt.*;
import javax.swing.*;
/**
 * Pane on pacman board.
 * @author Ronald Chan Rushil Saha
 * @version 5/4/17
 */
public class Square extends JPanel
{
    private String contents;//string name of contents ex:food
    private boolean pacMan;//true if has pac, else false
    private int blinkCount;
    private int direction;
    private boolean open;//mouth open/shut
    private Image [][] face;
    private Image[][]walls;
    private Color gColor;
    private boolean pic;
    private boolean ghost;
    private boolean vuln;
    private boolean flashing;
    private boolean imgWall;
    private int x;
    private int y;
    private boolean lingGhost;
    /**
     * Initializes all of the instance variables, and sets
     * contents to desired string.
     * 
     * @param       String contents, set as instance var
     *              contents.
     */
    public Square(String con,Image[][]faces,Image[][]wall,boolean img,boolean w,int locX,int locY)
    {
        contents=con;
        pacMan=false;
        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(30,30));
        ghost=false;
        walls=wall;
        face=faces;
        pic=img;
        imgWall=w;
        x=locX;
        y=locY;
        lingGhost=false;
    }

    /**
     * Paints panel according to what desired content is. 
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        if(imgWall)
        {
        	g.drawImage(walls[6][0],0,0,30,30,x*30,y*30,x*30+30,y*30+30,Color.BLUE,null);
        }
        else
        {
        setBackground(Color.BLACK);
        }
        if(contents.equals(""))
        {
        }
        else if(contents.equals("food"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[7][0], 0, 0, 30, 30, null);
        	}
        	else
        	{
            g.setColor(Color.WHITE);
            g.fillOval(12,12,6,6);
        	}
        }
        else if(contents.equals("v_wall"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[1][0],0,0,30,30,null);
        	}
        	else
        	{
            g.setColor(Color.BLUE);
            g.fillRect(13,0,4,30);
        	}
        }
        else if(contents.equals("h_wall"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[0][0],0,0,30,30,null);
        	}
        	else
        	{
            g.setColor(Color.BLUE);
            g.fillRect(0,13,30,4);
        	}
        }
        else if(contents.equals("botleft_wall"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[4][0],0,0,30,30,null);
        	}
        	else
        	{
            g.setColor(Color.BLUE);
            g.fillRect(13,0,4,15);
            g.fillRect(15,13,15,4);
        	}
        }
        else if(contents.equals("botright_wall"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[5][0],0,0,30,30,null);
        	}
        	else
        	{
            g.setColor(Color.BLUE);
            g.fillRect(13,0,4,15);
            g.fillRect(0,13,15,4);
        	}
        }
        else if(contents.equals("topleft_wall"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[2][0],0,0,30,30,null);
        	}
        	else
        	{
            g.setColor(Color.BLUE);
            g.fillRect(13,15,4,15);
            g.fillRect(15,13,15,4);
        	}
        }
        else if(contents.equals("topright_wall"))
        {
        	if(imgWall)
        	{
        		g.drawImage(walls[3][0],0,0,30,30,null);
        	}
        	else
        	{
            g.setColor(Color.BLUE);
            g.fillRect(13,15,4,15);
            g.fillRect(0,13,15,4);
        	}
        }
        else if(contents.equals("sp_food"))
        {
        	
            if(blinkCount==4)
            {
                blinkCount=0;
            }
            else
            {
            	if(imgWall)
            	{
            		g.drawImage(walls[8][0],0,0,30,30,null);
            	}
            	else
            	{
                g.setColor(Color.WHITE);
                g.fillOval(5,5,20,20);
                blinkCount++;
            	}
            }
        }
        if(ghost)
        {
        	if(vuln)
        	{
        			if(imgWall)
        			{
        				g.drawImage(walls[10][0],0,0,30,30,null);
        			}
        			else
        			{
        			g.setColor(Color.BLUE);
        			g.fillOval(5, 5, 20,20);
        			}
        		
        	}
        	else
        	{
        		if(imgWall)
        		{
        			g.drawImage(walls[9][0], 0, 0, 30, 30, null);
        		}
        		else
        		{
        		g.setColor(gColor);
        		g.fillOval(5,5,20,20);
        		}
        	}
        }
        if (pacMan)
        {
            if(pic)
            {
                if(open)
                {
                    g.drawImage(face[direction/90][0],0,0,30,30,null);
                }
                else
                {
                    g.drawImage(face[direction/90][1],0,0,30,30,null);
                }
            }
            else
            {
                g.setColor(Color.YELLOW);
                g.fillOval(0,0,30,30);
                g.setColor(Color.BLACK);
                int []x={15,0,0};
                int []y={15,0,30};
                if(!open)
                {
                    open=true;
                }
                else 
                {
                    if(direction==90)
                    {
                        x[2]=30;
                        y[2]=0;
                    }
                    else if(direction==270)
                    {
                        x[1]=30;
                        y[1]=40;
                    }
                    else if(direction==0)
                    {
                        x[1]=30;
                        y[1]=30;
                        x[2]=30;
                        y[2]=0;
                    }
                    g.fillPolygon(x,y,3);
                    open=false;
                }
            }
        }
    }
    public void setLingGhost(boolean ghost)
    {
    	lingGhost=ghost;
    }
    public boolean getLingGhost()
    {
    	return lingGhost;
    }
    /**
     * Allows repaint to be called from other classes.
     */
    public void update()
    {
        repaint();
    }

    /**
     * Allows private var contents to be accessed from other classes.
     * 
     * @return         String contents, desc. of panel contents
     */
    public String getContents()
    {
        return contents;
    }
    /**
     * Sets vuln to desired value.
     * 
     * @param			boolean desired value of vuln
     */
    public void setVuln(boolean vul)
    {
    	vuln=vul;
    }
    /**
     * Returns value of vuln.
     * 
     * @return			boolean value of vuln
     */
    public boolean getVuln()
    {
    	return vuln;
    }
    /**
     * Sets flashing to desired value.
     * 
     * @param			boolean desired value of flashing
     */
    public void setFlashing(boolean flash)
    {
    	flashing=flash;
    }
    /**
     * Returns value of flashing.
     * 
     * @return			boolean value of flashing
     */
    public boolean getFlashing()
    {
    	return flashing;
    }
    /**
     * Allows private var contents to be changed from other classes.
     * 
     * @param         String to set as contents
     */
    public void setContents(String s)
    {
        contents=s;
    }

    /**
     * Allows other classes to set pac man existence in panel.
     * 
     * @param         boolean true if pac is desired, else false
     */
    public void setPac(boolean pac)
    {
        pacMan=pac;
    }
    
    /**
     * Sets the private instance variable ghost.	
     * 
     * @param			boolean desired contents of ghost
     */
    public void setGhost(boolean spook)
    {
    	ghost=spook;
    }
    
    /**
     * Allows other classes to read the private variable ghost.
     * 
     * @return			boolean current val of ghost
     */
    public boolean getGhost()
    {
    	return ghost;
    }
    /**
     * Sets the private variable gColor for ghost color.
     * 
     * @param			Color desired of ghost
     */
    public void setGColor(Color col)
    {
    	gColor=col;
    }
    /**
     * Returns color of ghost on square.
     * 
     * @return			Color of ghost
     */
    public Color getGColor()
    {
    	return gColor;
    }
    /**
     * Sets the instance variable direction.
     * 
     * @param           int desired direction of pacman.
     */
    public void setDirection(int dir)
    {
        direction=dir;
    }

    /**
     * Sets whether or not pac's mouth is open/closed.
     * 
     * @param           boolean true if open, false if closed
     */
    public void setMouth(boolean mouth)
    {
        open=mouth;
    }
}