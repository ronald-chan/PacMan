import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * Runs the pacman game for now, not for use in final
 * @author Ronald Chan Rushil Saha
 * @version 5/4/17
 */
public class PacmanGame extends JFrame
{
    private int pacX,pacY, destX,destY;//location of pac man and intended end loc respectively
    public Square [][] panels; //grid on which game play happens
    private final String H="h_wall";
    private final String V="v_wall";
    private final String TL="topleft_wall";
    private final String TR="topright_wall";
    private final String BL="botleft_wall";
    private final String BR="botright_wall";
    private final String F="food";
    private final String SF="sp_food";
    private final String [][]map1= //used to create map
        {{TL,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,TR},
            {V,TL,H,H,H,H,H,H,H,H,H,H,H,H,TR,TL,H,H,H,H,H,H,H,H,H,H,H,H,TR,V},
            {V,V,F,F,F,F,F,F,F,F,F,F,F,F,V,V,F,F,F,F,F,F,F,F,F,F,F,F,V,V},
            {V,V,F,TL,H,H,TR,F,TL,H,H,H,TR,F,V,V,F,TL,H,H,H,TR,F,TL,H,H,TR,F,V,V},
            {V,V,SF,V,"","",V,F,V,"","","",V,F,V,V,F,V,"","","",V,F,V,"","",V,SF,V,V},
            {V,V,F,BL,H,H,BR,F,BL,H,H,H,BR,F,BL,BR,F,BL,H,H,H,BR,F,BL,H,H,BR,F,V,V},
            {V,V,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,V,V},
            {V,V,F,TL,H,H,TR,F,TL,TR,F,TL,H,H,H,H,H,H,TR,F,TL,TR,F,TL,H,H,TR,F,V,V},
            {V,V,F,BL,H,H,BR,F,V,V,F,BL,H,H,TR,TL,H,H,BR,F,V,V,F,BL,H,H,BR,F,V,V},
            {V,V,F,F,F,F,F,F,V,V,F,F,F,F,V,V,F,F,F,F,V,V,F,F,F,F,F,F,V,V},
            {V,BL,H,H,H,H,TR,F,V,BL,H,H,TR,"",V,V,"",TL,H,H,BR,V,F,TL,H,H,H,H,BR,V},
            {BL,H,H,H,H,TR,V,F,V,TL,H,H,BR,"",BL,BR,"",BL,H,H,TR,V,F,V,TL,H,H,H,H,BR},
            {"","","","","",V,V,F,V,V,"","","","","","","","","","",V,V,F,V,V,"","","","",""},
            {H,H,H,H,H,BR,V,F,V,V,"",TL,H,H,H,H,H,H,TR,"",V,V,F,V,BL,H,H,H,H,H},
            {H,H,H,H,H,H,BR,F,BL,BR,"",V,"","","","","","",V,"",BL,BR,F,BL,H,H,H,H,H,H},
            {"","","","","","","","","","","",V,"","","","","","",V,"","","","","","","","","","",""},
            {H,H,H,H,H,H,TR,F,TL,TR,"",V,"","","","","","",V,"",TL,TR,F,TL,H,H,H,H,H,H},
            {H,H,H,H,H,TR,V,F,V,V,"",BL,H,H,H,H,H,H,BR,"",V,V,F,V,TL,H,H,H,H,H},
            {"","","","","",V,V,F,V,V,"","","","","","","","","","",V,V,F,V,V,"","","","",""},
            {TL,H,H,H,H,BR,V,F,V,V,"",TL,H,H,H,H,H,H,TR,"",V,V,F,V,BL,H,H,H,H,TR},
            {V,TL,H,H,H,H,BR,F,BL,BR,"",BL,H,H,TR,TL,H,H,BR,"",BL,BR,F,BL,H,H,H,H,TR,V},
            {V,V,F,F,F,F,F,F,F,F,F,F,F,F,V,V,F,F,F,F,F,F,F,F,F,F,F,F,V,V},
            {V,V,F,TL,H,H,TR,F,TL,H,H,H,TR,F,V,V,F,TL,H,H,H,TR,F,TL,H,H,TR,F,V,V},
            {V,V,F,BL,H,TR,V,F,BL,H,H,H,BR,F,BL,BR,F,BL,H,H,H,BR,F,V,TL,H,BR,F,V,V},
            {V,V,SF,F,F,V,V,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,V,V,F,F,SF,V,V},
            {V,BL,H,TR,F,V,V,F,TL,TR,F,TL,H,H,H,H,H,H,TR,F,TL,TR,F,V,V,F,TL,H,BR,V},
            {V,TL,H,BR,F,BL,BR,F,V,V,F,BL,H,H,TR,TL,H,H,BR,F,V,V,F,BL,BR,F,BL,H,TR,V},
            {V,V,F,F,F,F,F,F,V,V,F,F,F,F,V,V,F,F,F,F,V,V,F,F,F,F,F,F,V,V},
            {V,V,F,TL,H,H,H,H,BR,BL,H,H,TR,F,V,V,F,TL,H,H,BR,BL,H,H,H,H,TR,F,V,V},
            {V,V,F,BL,H,H,H,H,H,H,H,H,BR,F,BL,BR,F,BL,H,H,H,H,H,H,H,H,BR,F,V,V},
            {V,V,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,V,V},
            {V,BL,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,BR,V},
            {BL,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,H,BR}};
    KeyMoving heh; //takes user input
    private int score;
    private int lives;
    private boolean invMode;//true if invinc, else false
    private Timer invTime;//times invincibility time for pac
    private int invisTime;//milliseconds
    private InvisTimer flash; //listener for invincibility after super food
    private int [][]spFoodLoc; //holds location of special pellets
    private Timer flashFood; //timer for flashing pellets
    private SpecialFood timeFood; //listener for flashing pellets
    private int direction; //direction that pac man is facing
    private boolean open;//whether pac man's mouth is open/closed
    private GhostRunner gRunner;
    private Timer pacTimer; //rate at which pac moves
    private Image[][]face;
    private Image[][]wall;
    private boolean imgWall;
    private boolean imgPac;
    /**
     * Initializes all of the instance vars.
     */
    public PacmanGame()
    {
        pacX=15;
        pacY=18;
        destX=15;
        destY=18;
        invisTime=1000;
        heh = new KeyMoving();
        flash=new InvisTimer();
        invTime=new Timer(8000,flash);
        spFoodLoc=new int[4][2]; //first index is set of coordinates, second set is x and y in order.
        timeFood=new SpecialFood();
        flashFood=new Timer(250,timeFood);
        direction=0;
        lives=4;
        face = new Image[4][2];//first index orientation, second open/close
        face[1][0]=new ImageIcon("OpenUp.png").getImage();
        face[2][0]=new ImageIcon("OpenLeft.png").getImage();
        face[0][0]=new ImageIcon("OpenRight.png").getImage();
        face[3][0]=new ImageIcon("OpenDown.png").getImage();
        face[1][1]=new ImageIcon("ClosedUp.png").getImage();
        face[2][1]=new ImageIcon("ClosedLeft.png").getImage();
        face[0][1]=new ImageIcon("ClosedRight.png").getImage();
        face[3][1]=new ImageIcon("ClosedDown.png").getImage();
        wall=new Image[11][1];
        wall[0][0]=new ImageIcon("HSeaweed.png").getImage();
        wall[1][0]=new ImageIcon("VSeaweed.png").getImage();
        wall[2][0]=new ImageIcon("TLSeaweed.png").getImage();
        wall[3][0]=new ImageIcon("TRSeaweed.png").getImage();
        wall[4][0]=new ImageIcon("BLSeaweed.png").getImage();
        wall[5][0]=new ImageIcon("BRSeaweed.png").getImage();
        wall[6][0]=new ImageIcon("SeaBackground.png").getImage();
        wall[7][0]=new ImageIcon("SeaFood.png").getImage();
        wall[8][0]=new ImageIcon("SeaSpecial.png").getImage();
        wall[9][0]=new ImageIcon("SeaGhost.png").getImage();
        wall[10][0]=new ImageIcon("SeaGhostVuln.png").getImage();
        imgWall=true;
        imgPac=true;
    }

    public static void main(String [] args)
    {
        PacmanGame bruh = new PacmanGame();
        bruh.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bruh.setUpGame();
        bruh.setVisible(true);
    }

    /**
     * Temporary hub from which everything is called. Sets up the
     * grid, then key/action listeners take over. 
     */
    public void setUpGame()
    {
        setLayout(new GridLayout(33,30));
        panels = new Square[30][33];
        String content="food";
        int counter=0;
        for(int i=0;i<33;i++)
        {
            for(int z=0;z<30;z++)
            {
                panels[z][i]=new Square(map1[i][z],face,wall,false,false,z,i);//first boolean for face, second for walls n background
                panels[z][i].repaint();
                if(map1[i][z].equals(SF))
                {
                    spFoodLoc[counter][0]=z;
                    spFoodLoc[counter][1]=i;
                    counter++;
                }
            }
        }
        panels[pacX][pacY].setPac(true);
        for(int i=0;i<33;i++)
        {
            for(int z=0;z<30;z++)
            {
                add(panels[z][i]);//adds panels into frame
                pack();
            }
        }
        gRunner = new GhostRunner(panels);
        updateRunnerLoc();
        flashFood.start();
    }

    /**
     * Checks if the board is clear of all pellets
     * @return  true if board is clear
     *          else false
     */
    public boolean gameWon()
    {
        for(int i=0;i<30;i++)
        {
            for (int z=0;z<33;z++)
            {
                if(panels[i][z].getContents().indexOf("food")!=-1)
                {
                    return false;
                }
            }
        }
        return true;
    }
    /**
     * Passes through to the Ghost Runner class the updated coordinates
     * of pacman.
     */
    public void updateRunnerLoc()
    {
    	gRunner.setPacLoc(pacX,pacY);
    }
    /**
     * Takes user input and makes the pac-man move accordingly.
     */
    class KeyMoving implements KeyListener
    {
        int counter;
        private Movement kevin; //listener for timer
        public KeyMoving()
        {
            addKeyListener(this);
            kevin = new Movement();
            pacTimer=new Timer(150,kevin);
            counter=0;
            pacTimer.stop();
        }

        public void keyTyped(KeyEvent e)
        {
        }

        /**
         * Changes end location of pac man.
         * @param KeyEvent e that describes what happened
         */
        public void keyPressed(KeyEvent e)
        {
            int k = e.getKeyCode();
            int i=0;
            if(k==KeyEvent.VK_UP)
            {
                i=pacY-1;
                while(i>=0)
                {
                    if(panels[pacX][i].getContents().indexOf("wall")==-1)
                    {
                        destY=i;
                        destX=pacX;
                        direction=90;
                    }
                    else
                    {
                        i=-1;
                    }
                    i--;
                }
            }
            else if(k==KeyEvent.VK_LEFT)
            {
                i=pacX-1;
                while(i>=0)
                {
                    if(panels[i][pacY].getContents().indexOf("wall")==-1)
                    {
                        destX=i;
                        destY=pacY;
                        direction=180;
                    }
                    else
                    {
                        i=-1;
                    }
                    i--;
                }
            }
            else if(k==KeyEvent.VK_DOWN)
            {
                i=pacY+1;
                while(i<33)
                {
                    if(panels[pacX][i].getContents().indexOf("wall")==-1)
                    {
                        destY=i;
                        destX=pacX;
                        direction=270;
                    }
                    else
                    {
                        i=33;
                    }
                    i++;
                }
            }
            else if(k==KeyEvent.VK_RIGHT)
            {
                i=pacX+1;
                while(i<30)
                {
                    if(panels[i][pacY].getContents().indexOf("wall")==-1)
                    {
                        destX=i;
                        destY=pacY;
                        direction=0;
                    }
                    else
                    {
                        i=30;
                    }
                    i++;
                }
            }
            pacTimer.start();
        }

        public void keyReleased(KeyEvent e)
        {
        }

        /**
         * Used by timer to make pacman movement at a certain rate.
         */
        class Movement implements ActionListener
        {
            int counter;
            /**
             * Calls method to move pacman with timer.
             * @param ActionEvent   timer
             */
            public void actionPerformed(ActionEvent e)
            {
                if(counter%2==0)
                {
                    moving();
                }
                else
                {
                }
            }

            /**
             * Makes panels near pac man repaint, and adjusts coordinates
             * for pac man. 
             */
            public void moving()
            {
            	if(panels[pacX][pacY].getGhost()||panels[pacX][pacY].getLingGhost())
                {
                	if(invMode)
                	{
                		score+=100;
                		gRunner.resetGhost(pacX, pacY);
                	}
                	else
                	{
                		lives--;
                		gRunner.stop();
                		pacTimer.stop();
                		resetBoard(1);
                	}
                }
                panels[pacX][pacY].setPac(false);
                panels[pacX][pacY].repaint();
                if(pacY==15&&pacX==0)
                {
                    pacX=29;
                    destX=19;
                }
                else if(pacY==15&&pacX==29)
                {
                    pacX=0;
                    destX=10;
                }
                if(pacX<destX&&pacX<30)                 
                {
                    pacX++;
                }
                else if(pacX>destX&&pacX>0)
                {
                    pacX--;
                }
                else if(pacY< destY&&pacY<33)                
                {
                    pacY++;
                }
                else if(pacY>destY&&pacY>0)
                {
                    pacY--;
                }
                if(panels[pacX][pacY].getContents().equals(F))
                {
                    score++;
                }
                else if(panels[pacX][pacY].getContents().equals(SF))
                {
                    invMode=true;
                    score+=50;
                    invTime.stop();
                    invTime=new Timer(8000,flash);
                    invTime.start();
                    gRunner.setVuln(true);
                }
                updateRunnerLoc();
                panels[pacX][pacY].setContents("");
                panels[pacX][pacY].setPac(true);
                panels[pacX][pacY].setDirection(direction);
                panels[pacX][pacY].setMouth(open);
                if(pacX==destX&&pacY==destY)
                {
                    panels[pacX][pacY].setMouth(true);
                    panels[pacX][pacY].setContents("");
                }
                panels[pacX][pacY].repaint();
                open=!open;
                if(gameWon())
                {
                    lives++;
                    resetBoard(0);
                }
            }
        }
    }
    /**
     * Resets board to either beginning or just positions, depending on
     * parameter. 
     * 
     * @param		int 0 for full reset, 1 for soft reset
     */
    public void resetBoard(int deg)
    {
    	gRunner.resetPos();
    	panels[pacX][pacY].setPac(false);
    	panels[pacX][pacY].repaint();
    	pacX=15;
    	pacY=18;
    	destX=15;
    	destY=18;
    	direction=0;
    	if(deg==0)
    	{
    		for(int i=0;i<30;i++)
    		{
    			for(int z=0;z<33;z++)
    			{
    				remove(panels[i][z]);
    			}
    		}
    		setUpGame();
    	}
    	gRunner.start();
    	pacTimer.start();
    }
    /**
     * Performs the blinking of food pellets. Repaints just the select panels,
     * called by the timer. 
     */
    class SpecialFood implements ActionListener
    {
        /**
         * Repaints panels periodically with the special pellets, allowing 
         * for flashing effect in real game. 
         * 
         * @param ActionEvent timer
         */
        public void actionPerformed(ActionEvent e)
        {
            for(int i=0;i<4;i++)
            {
                if(!(pacX==spFoodLoc[i][0]&&pacY==spFoodLoc[i][1]))
                {
                    panels[spFoodLoc[i][0]][spFoodLoc[i][1]].repaint();
                }
            }
        }
    }
    /**
     * Turns invincibility off and makes ghosts blink.
     */
    class InvisTimer implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
        	invMode=false;
        	gRunner.setVuln(false);
        	invTime.stop();
        }
    }
    class ResetTimer implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		gRunner.start();
    		pacTimer.start();
    	}
    }
}