import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * GhostRunner.java
 * @author Ronald Chan Rushil Saha
 * @version 5/4/17
 * Updates panels with ghosts in them.
 */
public class GhostRunner
{
	private int numGhosts;
	private Ghost [] ghosts;
	private Ghost test;
	private GhostMove ghostMoveListener;
	private Timer ghostMove;
	private int pacX,pacY;
	private int[]destX={21,21,8,8};
	private int[]destY={27,3,27,3};
	private int []startX={12,17,12,17};
	private int[]startY={14,14,16,16};
	private int[]moveType={-1000,-1000,-1000,-1000};
	private Color[]colors={Color.RED,Color.CYAN,Color.ORANGE,Color.MAGENTA};
	private Square[][]panels;
	private boolean[]inCage;
	public GhostRunner(Square[][]pan)
	{
		panels=pan;
		ghosts = new Ghost[4];
		inCage=new boolean[4];
		for(int i=0;i<ghosts.length;i++)
		{
			ghosts[i]=new Ghost(panels,startX[i],startY[i],colors[i]);
		}
		for(int i=0;i<4;i++)
		{
			inCage[i]=true;
		}
		
		
		ghostMoveListener=new GhostMove();
		ghostMove=new Timer(250,ghostMoveListener);
		ghostMove.start();
	}
	/**
	 * Sets the instance var to new location of pac.
	 * 
	 * @param 			int x location of pac
	 * @param 			int y location of pac
	 */
	public void setPacLoc(int x,int y)
	{
		pacX=x;
		pacY=y;
	}
	/**
	 * Starts the movement of ghosts.
	 */
	public void start()
	{
		ghostMove.start();
	}
	/**
	 * Stops the movement of ghosts.
	 */
	public void stop()
	{
		ghostMove.stop();
	}
	/**
	 * Reverts positions and status of ghosts to original.
	 */
	public void resetPos()
	{
		for(int i=0;i<ghosts.length;i++)
		{
			moveType[i]=-100;
			panels[ghosts[i].getLocX()][ghosts[i].getLocY()].setGhost(false);
			panels[ghosts[i].getLastX()][ghosts[i].getLastY()].setLingGhost(false);
			panels[ghosts[i].getLocX()][ghosts[i].getLocY()].repaint();
			ghosts[i].setLocX(startX[i]);
			ghosts[i].setLocY(startY[i]);
			ghosts[i].setVuln(false);
			panels[startX[i]][startY[i]].repaint();
			inCage[i]=true;
		}
	}


	/**
	 * Resets a single ghost given coordinates, used for pac
	 * eating a ghost.
	 * 
	 * @param			int current x location of ghost
	 * @param			int current y location of ghost
	 */
	public void resetGhost(int x,int y)
	{
		for(int i=0;i<ghosts.length;i++)
		{
			if(ghosts[i].getLocX()==x&&ghosts[i].getLocY()==y)
			{
				panels[x][y].setGhost(false);
				panels[ghosts[i].getLastX()][ghosts[i].getLastY()].setLingGhost(false);
				panels[x][y].repaint();
				ghosts[i].setVuln(false);
				ghosts[i].setLocX(startX[i]);
				ghosts[i].setLocY(startY[i]);
				panels[startX[i]][startY[i]].setGhost(true);
				panels[startX[i]][startY[i]].repaint();
				moveType[i]=-100;
				inCage[i]=true;
			}
		}
	}
	/**
	 * Sets vulnerability of all the ghosts.
	 * 
	 * @param			boolean desired value of vuln
	 */
	public void setVuln(boolean vul)
	{
		if(vul)
		{
			for(int i=0;i<4;i++)
			{
			moveType[i]=-80;
			}
		}
		for(int i=0;i<ghosts.length;i++)
		{
			ghosts[i].setVuln(vul);
			ghosts[i].setDirection(Math.abs(ghosts[i].getDirection()-180));
		}
	}
	/**
	 * Calculates movement of ghosts, and refreshes panels. 
	 */
	class GhostMove implements ActionListener
	{
		int counter=20;
		boolean blinking=false;
		/**
		 * Calls methods that generate movement, and call repaint methods within.
		 */
		public void actionPerformed(ActionEvent e)
		{
			if(counter==30)
			{
				for(int i=0;i<4;i++)
				{
					if(inCage[i])
					{
						panels[ghosts[i].getLocX()][ghosts[i].getLocY()].setGhost(false);
						panels[ghosts[i].getLocX()][ghosts[i].getLocY()].repaint();
						ghosts[i].setLocX(14);
						ghosts[i].setLocY(12);
						ghosts[i].setLastX(14);
						ghosts[i].setLastY(12);
						ghosts[i].setDirection((int)(Math.random()*2)*180);
						panels[14][12].setGhost(true);
						panels[14][12].repaint();
						inCage[i]=false;
						moveType[i]=0;
						i=4;
					}
					
				}
				counter=0;
			}
			else
			{
				counter++;
			}
			for(int i=0;i<4;i++)
			{
				if(moveType[i]==-100)
				{
					ghosts[i].generateRand();
				}
				if(moveType[i]<0)
				{
					ghosts[i].setBlinking(blinking);
					ghosts[i].generateVuln();

					if(moveType[i]>-40)
					{
						blinking=!blinking;
					}
					if(moveType[i]==-1)
					{
						blinking=false;
					}
				}
				else if(moveType[i]<80)
				{
					
						ghosts[i].generateMove(pacX,pacY);
				
				}
				else if (moveType[i]<108)
				{
					
						ghosts[i].generateMove(destX[i],destY[i]);
					
				}
				if(moveType[i]==107)
				{
					moveType[i]=0;
				}
				else if(moveType[i]!=-100)
				{
					moveType[i]++;
				}
			}
		}
	}
}